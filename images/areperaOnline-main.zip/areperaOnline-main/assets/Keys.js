export default {
  public: "Aquí debes colocar tu clave publica",
  secret: "Aquí debes colocar tu clave privada"
}